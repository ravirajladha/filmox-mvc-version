<?php require APPROOT.'/views/inc/header.php';?>
<!-- Box -->
    <!-- <div class="box text-center">
        <div class="box-item">
            <i class="ti-vector"></i>
            <h6 class="box-title">UX/UI Design</h6>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis excepturi, repellat esse laborum explicabo quia.</p>
        </div>
        <div class="box-item">
            <i class="ti-filter"></i>
            <h6 class="box-title">Web Development</h6>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis excepturi, repellat esse laborum explicabo quia.</p>
        </div>
        <div class="box-item">
            <i class="ti-mobile"></i>
            <h6 class="box-title">App Design</h6>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis excepturi, repellat esse laborum explicabo quia.</p>
        </div>
    </div> -->
    <!-- End of Box -->

    <!-- About Section -->
    <section id="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-5 col-lg-4">
                    <img src="assets/imgs/about.jpg" alt="image not found" class="w-100 img-thumbnail mb-3">
                </div>
                <div class="col-md-7 col-lg-8">
                    <!-- <h6 class="section-subtitle mb-0">We Create</h6> -->
                    <h6 class="section-title mb-3">About Us</h6>
                    <p style="font-size:20px;">Filmox connects Artists with digital/channel partners who are looking for professional artists. We are a social network and online platform for professional artists. People use our Services to find and be found for work and business opportunities, to connect with others, find information, get training and be more productive.</p>
                    <!-- <p>Cum laudantium unde nemo doloribus eligendi quodarum ea vitae dicta. Accusantium vero, ea? Alias, atque libero. Id, ut harum. </p>
                    <p>consectetur adipisicing elit. Omnis quidem, quos iure a dolorum illum culpa quia nemo soluta, ratione harum beatae minus doloribus consectetur! Similique tempora sunt doloribus molestias.</p> -->
                </div>
            </div>
        </div>
    </section>
    <!-- End of About Section -->

    <!-- About Section with bg -->
    <!-- <section class="has-bg-img py-md">
        <div class="container text-center">
            <h6 class="section-subtitle">We See</h6>
            <h6 class="section-title mb-6">What Other Don't See.</h6>
            <div class="widget mb-4">
                <div class="widget-item">
                    <i class="ti-notepad"></i>
                    <h4>Planning</h4>
                </div>
                <div class="widget-item">
                    <i class="ti-layout"></i>
                    <h4>Mockup</h4>
                </div>
                <div class="widget-item">
                    <i class="ti-filter"></i>
                    <h4>Develope</h4>
                </div>
                <div class="widget-item">
                    <i class="ti-thumb-up"></i>
                    <h4>Provide</h4>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End Of About Sectoin -->

    <!-- Service Section -->
    <!-- <section id="service">
        <div class="container">
            <h6 class="section-subtitle text-center">Makes Happen</h6>
            <h5 class="section-title text-center mb-6">Our Service</h5> 
            <div class="row">
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-filter text-primary"></i></h2>
                            <h6 class="card-title">corporis assumenda</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-paint-roller text-primary"></i></h2>
                            <h6 class="card-title">Debitis amet</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-ruler-pencil text-primary"></i></h2>
                            <h6 class="card-title">Libero temporibus</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-layers text-primary"></i></h2>
                            <h6 class="card-title">Perspiciatis explicabo</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-bolt text-primary"></i></h2>
                            <h6 class="card-title">Poluptatum</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-palette text-primary"></i></h2>
                            <h6 class="card-title">Nihil dicta</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-stats-up text-primary"></i></h2>
                            <h6 class="card-title">Repellendus maxime</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-md-3">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h2 class="mb-4"><i class="ti-location-arrow text-primary"></i></h2>
                            <h6 class="card-title">Sint vitae</h6>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis amet saepe et!</p>
                        </div>
                    </div>
                </div>

            </div>  
        </div>
    </section> -->
    <!-- End of Service Section -->

    <!-- Portfolio section -->
    <!-- <section id="portfolio">
        <div class="container text-center">
            <h6 class="section-subtitle">Our Awesome Works</h6>
            <h6 class="section-title mb-5">Our Portfolio</h6>
            <div class="row">
                <div class="col-sm-4">
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-1.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>  
                        </div>
                    </div>
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-2.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>                              
                        </div>
                    </div>                  
                </div>
                <div class="col-sm-4">
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-3.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>  
                        </div>
                    </div>
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-4.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>                              
                        </div>
                    </div>                  
                </div>
                <div class="col-sm-4">
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-5.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>  
                        </div>
                    </div>
                    <div class="img-wrapper">
                        <img src="assets/imgs/folio-6.jpg" alt="image not found">
                        <div class="overlay">
                            <div class="overlay-infos">
                                <h5>Project Title</h5>
                                <a href="javascript:void(0)"><i class="ti-zoom-in"></i></a>
                                <a href="javascript:void(0)"><i class="ti-link"></i></a>
                            </div>                              
                        </div>
                    </div>                  
                </div>
            </div>
        </div>
    </section> -->
    <!-- End of portfolio section -->

    <!-- Team Section -->
    <!-- <section id="team">
        <div class="container">
            <h6 class="section-subtitle text-center">Meet With</h6>
            <h6 class="section-title mb-5 text-center">Our Angels</h6>
            <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">FOUNDER</h6>
                            <h5 class="card-title">Matthew Davis</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar-1.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">CEO</h6>
                            <h5 class="card-title">Barbara Ross</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar-2.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">Designer</h6>
                            <h5 class="card-title">Karen Perry</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar-3.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">App Designer</h6>
                            <h5 class="card-title">Ashley Diaz</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar-4.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">Developer</h6>
                            <h5 class="card-title">Edward Harris</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4">
                    <div class="card text-center mb-4">
                        <img class="card-img-top inset" src="assets/imgs/avatar-5.jpg">
                        <div class="card-body">
                            <h6 class="small text-primary font-weight-bold">photographer</h6>
                            <h5 class="card-title">Brian Scott</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magni quos esse tenetur illo qui, nostrum.</p>
                            <div class="socials">
                                <a href="javascript:void(0)"><i class="ti-facebook"></i> </a>
                                <a href="javascript:void(0)"><i class="ti-github"></i></a>
                                <a href="javascript:void(0)"><i class="ti-dropbox"></i></a>
                                <a href="javascript:void(0)"><i class="ti-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section> -->
    <!-- End of Team Sectoin -->

    <!-- Fatcs Section -->
    <!-- <section class="has-bg-img bg-img-2">
        <div class="container text-center">
            <h6 class="section-subtitle">We Are Awesome</h6>
            <h6 class="section-title mb-6">Some Fun Fucts</h6>
                <div class="widget-2">
                    <div class="widget-item">
                        <i class="ti-cup"></i>
                        <h6 class="title">100+</h6>
                        <div class="subtitle">Awards Won</div>
                    </div>
                    <div class="widget-item">
                        <i class="ti-face-smile"></i>
                        <h6 class="title">100+</h6>
                        <div class="subtitle">Happy Clients</div>
                    </div>
                    <div class="widget-item">
                        <i class="ti-blackboard"></i>
                        <h6 class="title">845+</h6>
                        <div class="subtitle">Project Completed</div>
                    </div>
                    <div class="widget-item">
                        <i class="ti-comments-smiley"></i>
                        <h6 class="title">15K+</h6>
                        <div class="subtitle">Comments</div>
                    </div>
                </div>
        </div>
    </section> -->

    <!-- Testimonial Section -->
    <!-- <section id="testimonial">
        <div class="container">
            <h6 class="section-subtitle text-center">Testimonial</h6>
            <h6 class="section-title text-center mb-6">What Our Clients Says</h6>
            <div class="row">
                <div class="col-md-6">
                    <div class="testimonial-wrapper">
                        <div class="img-holder">
                            <img src="assets/imgs/avatar-5.jpg" alt="image not found">                     
                        </div>
                        <div class="body">
                            <p class="subtitle">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque doloribus autem aperiam earum nostrum omnis blanditiis corporis perspiciatis adipisci nihil.</p>
                            <h6 class="title">Richard Reb</h6>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="testimonial-wrapper">
                        <div class="img-holder">
                            <img src="assets/imgs/avatar-6.jpg" alt="image not found">                     
                        </div>
                        <div class="body">
                            <p class="subtitle">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque doloribus autem aperiam earum nostrum omnis blanditiis corporis perspiciatis adipisci nihil.</p>
                            <h6 class="title">John Doe</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End of Testimonial Section -->

    <!-- Video Section -->
    <!-- <section class="has-bg-img py-lg">
        <div class="container text-center"> -->

            <!-- Button trigger modal -->
            <!-- <button type="button" class="btn btn-outline-primary play-control" data-toggle="modal" data-target="#exampleModalCenter">
              <i class="ti-control-play" ></i>
            </button>
            <h6 class="section-title mt-4">See Our Intro Video</h6>

        </div>
    </section> -->
    <!-- End of Video Section -->

    <!-- Modal -->
    <!-- <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <iframe width="100%" height="475" src="https://www.youtube.com/embed/TP4THzsAa3M" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div> -->
    <!-- end of modal -->

    <!-- Blog Section -->
    <!-- <section id="blog">
        <div class="container">
            <h6 class="section-subtitle text-center">News Feeds</h6>
            <h6 class="section-title mb-6 text-center">Our Blog</h6>

            <div class="row">
                <div class="col-md-4">
                    <div class="card blog-post my-4 my-sm-5 my-md-0">
                        <img src="assets/imgs/blog-1.jpg" alt="image not found">
                        <div class="card-body">
                            <div class="details mb-3">
                                <a href="javascript:void(0)"><i class="ti-comments"></i> 123</a>
                                <a href="javascript:void(0)"><i class="ti-eye"></i> 123</a>
                            </div>
                            <h5 class="card-title">Possimus aliquam veniam</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae laudantium dolor nisi obcaecati, non laboriosam asperiores doloremque tempora repellendus iure!</p>
                            <a href="javascript:void(0)" class="d-block mt-3">Read More...</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card blog-post my-4 my-sm-5 my-md-0">
                        <img src="assets/imgs/blog-2.jpg" alt="image not found">
                        <div class="card-body">
                            <div class="details mb-3">
                                <a href="javascript:void(0)"><i class="ti-comments"></i> 434</a>
                                <a href="javascript:void(0)"><i class="ti-eye"></i> 987</a>
                            </div>
                            <h5 class="card-title">Repudiandae laudantium</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae laudantium dolor nisi obcaecati, non laboriosam asperiores doloremque tempora repellendus iure!</p>
                            <a href="javascript:void(0)" class="d-block mt-3">Read More...</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card blog-post my-4 my-sm-5 my-md-0">
                        <img src="assets/imgs/blog-3.jpg" alt="image not found">
                        <div class="card-body">
                            <div class="details mb-3">
                                <a href="javascript:void(0)"><i class="ti-comments"></i> 164</a>
                                <a href="javascript:void(0)"><i class="ti-eye"></i> 425</a>
                            </div>
                            <h5 class="card-title">Laboriosam asperiores</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae laudantium dolor nisi obcaecati, non laboriosam asperiores doloremque tempora repellendus iure!</p>
                            <a href="javascript:void(0)" class="d-block mt-3">Read More...</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- End of Blog Section -->

    <!-- Contact Section -->
    <section id="contact">
        <div class="container text-center">
            <div class="contact-card ">
                <div style="margin-left:25%;">
                <div class="infos " >
                    <!-- <h6 class="section-subtitle text-center">Get Here</h6> -->
                    <h6 class="section-title mb-4 text-center">Contact Us</h6>

                    <div class="item">
                        <i class="ti-location-pin"></i>
                        <div>
                            <h5 class="text-left">Location</h5>
                            <p>No47 6th cross canara bank colony Chandra Layout Bangalore 560072</p>
                        </div>                          
                    </div>
                    <div class="item">
                        <i class="ti-mobile"></i>
                        <div class="text-left">
                            <h5 >Phone Number</h5>
                            <p>86-86-86-45-83
                            </p>
                            <p>86-86-86-45-38

                            </p>
                        </div>                          
                    </div>
                    <!-- <div class="item">
                        <i class="ti-mobile"></i>
                        <div>
                            <h5>Phone Number</h5>
                            <p>86-86-86-45-38

                            </p>
                        </div>                          
                    </div> -->
                    <div class="item">
                        <i class="ti-email"></i>
                        <div class="mb-0 text-left" >
                            <h5>Email Address</h5>
                            <p>Filmoxapp@gmail.com
                            </p>
                        </div>
                    </div>
                </div>
                    <!-- <div class="item">
                        <i class="ti-world"></i>
                        <div class="mb-0">
                            <h5>example.com</h5>
                            <p>info@example.com</p>
                        </div>
                    </div> -->
                </div>
                <!-- <div class="form">
                    <h6 class="section-subtitle">Available 24/7</h6>
                    <h6 class="section-title mb-4">Get In Touch</h6>
                    <form>
                        <div class="form-group">
                            <input type="email" class="form-control form-control-lg" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-lg" id="exampleInputPassword1" placeholder="Password" required>
                        </div>
                        <div class="form-group">
                            <textarea name="contact-message" id="" cols="30" rows="7" class="form-control form-control-lg" placeholder="Message"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block btn-lg mt-3">Send Message</button>
                    </form>
                </div> -->
            </div>
        </div>
    </section>
    <!-- Contact Section -->
<?php require APPROOT.'/views/inc/footer.php';?>